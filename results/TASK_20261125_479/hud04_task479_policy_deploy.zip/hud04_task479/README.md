# HU_D04 task479 trained-policy delivery

TASK_20261125_479 finished successfully. Continued from task418 model+Adam+adaptive learning rate. New PPO updates:959; cumulative updates:3053; saved iteration:3052. Actual PPO training1573.663s, worker soft time-budget stop, child exit0. Original task300 rewards and requested upright-knee-toe motion unchanged. Environment/RNG state was reinitialized, not restored.

## Play the learned policy

Unzip in your configured limx_rl_lab/IsaacLab project root, which contains scripts/rsl_rl/play.py. Activate that project's IsaacLab Python environment and run:

```bash
python scripts/rsl_rl/play.py \
  --task LimX-HU-D04-01-Flat-BeyondMimic-No-State-Estimation \
  --checkpoint "$(pwd)/hud04_task479/final_checkpoint.pt" \
  --motion_file "$(pwd)/hud04_task479/motion.npz" \
  --num_envs 1 --device cuda:0 --real-time
```

Requires compatible project code, IsaacLab/IsaacSim and GPU/display. Training used IsaacLab2.3.2 image and RSL-RL3.1.2. Matching source commit:31273bafc829f44c344989e695cc43eafa8ae35b. Its public repository uses source-parts plus source-overlay; launch.py --verify-only reconstructs verified-source/workload. Never run bootstrap/train just to play.

For headless recording add: --headless --video --video_length 1250

play.py loads final_checkpoint.pt; it does NOT accept --deploy_yaml. replay_npz.py only replays the reference, not the trained policy.

Files: final_checkpoint.pt(full training/play/resume checkpoint),policy.pt(TorchScript),policy.onnx(ONNX),deploy.yaml(clean controller metadata),deploy_native.yaml(original tagged metadata),deploy_verification.json,completion.json,motion.npz(exact target),play_command.sh,SHA256SUMS. Do not use unsafe YAML loading on native tagged YAML.

All downloaded model bytes matched worker hashes. TorchScript CPU154->29 finite-output test passed. This is NOT GPU playback, sim-to-sim, convergence or hardware validation; hardware_approved=false. No credentials, signed URLs, or raw logs included.
