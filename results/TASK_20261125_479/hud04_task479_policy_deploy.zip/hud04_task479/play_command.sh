python scripts/rsl_rl/play.py \
  --task LimX-HU-D04-01-Flat-BeyondMimic-No-State-Estimation \
  --checkpoint "$(pwd)/hud04_task479/final_checkpoint.pt" \
  --motion_file "$(pwd)/hud04_task479/motion.npz" \
  --num_envs 1 --device cuda:0 --real-time
