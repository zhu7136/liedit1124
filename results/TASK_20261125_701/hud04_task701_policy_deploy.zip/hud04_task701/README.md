# HU_D04 task701 trained policy and deployment files

Task: TASK_20261125_701. Remote status5(completed), child exit0, worker soft-budget stop.
Fresh PPO training:2256 updates, saved iteration2255, actual PPO training3386.424s.
1x4090D24GB,4096environments,seed42,154actor inputs->29joint actions,episode30s.
Source commit:9740682ee58247e3270a0acaed5c4c802b04ec45.
Original TASK_20261124_300 rewards/contact penalty retained. No added upright/contact reward.

This is the NEW1334-frame motion_1_333_hold replacement, not the old task418/479 motion.
motion.npz:50fps,26.68s,first234frames unchanged,100-frame smooth transition,final20s hold.
Only final hold posture corrected: torso upright, whole-body COM centered laterally between legs.
Motion SHA256:132c760feee8b39f8ca9fd9285e84d89af197bdf4f4a1e7dce42c9ee8a16f798.

Files:
- policy.pt: exported TorchScript policy for a compatible controller.
- policy.onnx: exported ONNX policy.
- deploy.yaml: clean safe-loadable controller observation/action/config metadata.
- deploy_native.yaml: original tagged metadata for reference; DO NOT use unsafe YAML constructors.
- final_checkpoint.pt: full training checkpoint for compatible project playback/resume, not TorchScript.
- motion.npz: exact matching training reference.
- deploy_verification.json and completion.json: worker-side provenance/checks.
- SHA256SUMS: hashes of every other file in this package.

All downloaded bytes verified against final worker hashes before loading.
TorchScript CPU smoke test154->29 finite outputs PASSED; deploy observation/action dimensions verified.
Training completion is NOT proof of task success, GPU playback, sim-to-sim or hardware safety.
No hardware deployment authorized; hardware_approved=false. Validate in simulation before any hardware use.
No credentials, signed URLs or raw logs are included.
